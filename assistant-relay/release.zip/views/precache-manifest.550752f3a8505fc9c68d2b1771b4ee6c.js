self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0390f92b80b943cae24cae98b7aa02d9",
    "url": "/index.html"
  },
  {
    "revision": "2731defd4dec19172455",
    "url": "/static/css/2.25de4381.chunk.css"
  },
  {
    "revision": "2731defd4dec19172455",
    "url": "/static/js/2.e91f5ff5.chunk.js"
  },
  {
    "revision": "88f4d04aeb68112cfaf1",
    "url": "/static/js/main.4b450f4e.chunk.js"
  },
  {
    "revision": "1a2f2821d175e0fa084d",
    "url": "/static/js/runtime-main.9329b01b.js"
  }
]);