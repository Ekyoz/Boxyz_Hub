self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "983b8f7ad98a3a8e29df504a9657b2c2",
    "url": "/index.html"
  },
  {
    "revision": "2c2764ed04ac26ca977b",
    "url": "/static/css/2.08a37119.chunk.css"
  },
  {
    "revision": "2c2764ed04ac26ca977b",
    "url": "/static/js/2.56dab583.chunk.js"
  },
  {
    "revision": "1e8fcafd13439b7d4ed6",
    "url": "/static/js/main.95ecd077.chunk.js"
  },
  {
    "revision": "875d570ce1b6fc43afc6",
    "url": "/static/js/runtime-main.e077b804.js"
  }
]);