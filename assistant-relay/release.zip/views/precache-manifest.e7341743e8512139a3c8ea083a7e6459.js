self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a8429de4ec8cd12952669bd95fcb7d72",
    "url": "/index.html"
  },
  {
    "revision": "97527dab1c1671c0b7b8",
    "url": "/static/css/2.08a37119.chunk.css"
  },
  {
    "revision": "97527dab1c1671c0b7b8",
    "url": "/static/js/2.fe33700b.chunk.js"
  },
  {
    "revision": "00e245617090ea1c063f",
    "url": "/static/js/main.c1934ed1.chunk.js"
  },
  {
    "revision": "1a2f2821d175e0fa084d",
    "url": "/static/js/runtime-main.9329b01b.js"
  }
]);